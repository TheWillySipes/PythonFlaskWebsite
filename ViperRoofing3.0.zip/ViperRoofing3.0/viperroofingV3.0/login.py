import sqlite3
def login(username,password):
    user = ""
    passwords = ""
    print('username supplied is:',username)
    try:
        conn = sqlite3.connect('login.db')
        cur = conn.cursor()
        cur.execute('''SELECT * FROM login WHERE (username) == ?''',
                    (username,))
        results = cur.fetchall()
        print(results)
        for x in results:
            user = x[0]
            passwords = x[1]
    except sqlite3.Error as err:
        print('Database Error', err)
    finally:
        if conn != None:
            conn.close()
    print('usernames', username, user, "password", password, passwords)
    if username == user and password == passwords:
        print('welcome')
        return True
    else:
        print('failed login')
        print
        return False
##############################################################
def insert_row(username,password):
    #database kept seperate from main code
    conn = None
    try:
        conn = sqlite3.connect('login.db')
        cur = conn.cursor()
        cur.execute('''INSERT INTO login(username,password)
                    VALUES(?,?)''',
                    (username,password))
        conn.commit()
        print('row created!')
        success_code = 0
    except sqlite3.Error as err:
        success_code = -1
        print('Database Error' , err)
    finally:
        if conn != None:
            conn.close()
    return success_code
#############################################################
def update_row(username,password):
    conn = None
    try:
        conn = sqlite3.connect('login.db')
        cur = conn.cursor()
        cur.execute('''UPDATE login SET  username  = ?, password = ? WHERE (username) == ?''', (username, password, username))
        conn.commit()
        num_updated = cur.rowcount
        print('Update complete')
    except sqlite3.Error as err:
        print('Database Error', err)
    finally:
        if conn != None:
            conn.close()
    
    return num_updated
def housekeeping():
    username = input('enter the username')
    password = input('enter the password')
    login(username,password)

####################################################
def delete_row(username):
    conn = None
    try:
        conn = sqlite3.connect('login.db')
        cur = conn.cursor()
        cur.execute('''DELETE FROM login WHERE username == ?''',(username,))
        conn.commit()
        num_deleted = cur.rowcount
    except sqlite3.Error as err:
        print('Database Error', err)
    finally:
        if conn != None:
            conn.close()
    return num_deleted
###########################################
def read_one(username):
    results = []
    conn = None
    user = ""
    passwords = ""
    try:
        conn = sqlite3.connect('login.db')
        cur = conn.cursor()
        cur.execute('''SELECT * FROM login WHERE username == ?''',(username,))
        results = cur.fetchall()
        conn.commit()
        for x in results:
            user = x[0]
            passwords = x[1]
        success_code = 0
    except sqlite3.Error as err:
        print('Database Error', err)
        success_code = -1
    finally:
        if conn != None:
            conn.close()
            #print('usernames', username, "password", password)
    return user, passwords

#####################
def read(search):
    try:
        conn = sqlite3.connect('login.db')
        cur = conn.cursor()
        cur.execute(search)
        results = cur.fetchall()
        for row in results:
            username = row [0]
            password = row [1]
    except sqlite3.Error as err:
        print('Database Error', err)
    finally:
        if conn != None:
            conn.close()
    return results
#########################################
if __name__ == '__main__':
    housekeeping()
