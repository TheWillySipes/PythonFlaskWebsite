import sqlite3
import viper_read_one, viper_create

# The delete function deletes an item.
def delete():
    viper_create.housekeeping('Viper Delete')
    CustomerID = 0
    customername = ""
    address = ""
    phonenumber = ""
    email = ""
    sqft = 0
    roofage = 0
    conroof = 0
    roofgrade = ""
    mats = ""
    CustomerID, customername, address, phonenumber,email, sqft, roofage, conroof,roofgrade, mats = viper_read_one.searchCustomerName()

    if CustomerID == "-1":
        print("Customer not found")
    else:
        sure = input ("Are you sure you want to delete this word? (y/n)")
        if sure.lower() == 'y':
            num_deleted = delete_row(CustomerID)
            print(f'{num_deleted} row(s) deleted')

# The delete_row function deletes an existing item.
# The number of rows deleted in returned.
def delete_row(CustomerID):
    conn = None
    try:
        conn = sqlite3.connect('viperquotes.db')
        cur = conn.cursor()
        cur.execute('''DELETE FROM quotes WHERE CustomerID == ?''',(CustomerID,))
        conn.commit()
        num_deleted = cur.rowcount
    except sqlite3.Error as err:
        print('Database Error', err)
    finally:
        if conn != None:
            conn.close()
    return num_deleted

# Execute the main function.
if __name__ == '__main__':
    delete()
