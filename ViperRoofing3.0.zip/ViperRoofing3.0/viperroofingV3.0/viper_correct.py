import sqlite3
import viper_read_one, viper_create

    

# The update function updates an existing item's data.
def update():
    x = 100
    viper_create.housekeeping('Viper Update')
    CustomerID = 0
    customername = ""
    address = ""
    phonenumber = ""
    email = ""
    sqft = 0
    roofage = 0
    conroof = 0
    roofgrade = ""
    mats = ""
    conn = None
    results = []
    CustomerID, customername, address, phonenumber,email, sqft, roofage, conroof,roofgrade, mats = viper_read_one.searchCustomerName()
    if CustomerID == "-1":
        print("Customer not found")
    else:
        customername = input(f'{"Customers Name:":{x}}')
        address =  input(f'{"Address:":{x}}')
        phonenumber =  input(f'{"Phone Number:":{x}}')
        email =  input(f'{"E-Mail:":{x}}')
        sqft = input(f'{"Square Feet:":{x}}')
        roofage = input(f'{"Roofage:":{x}}')
        conroof = input(f'{"Con Roof:":{x}}')
        roofgrade = input(f'{"Roof Grade:":{x}}')
        mats = input(f'{"Mats:":{x}}')
        #correct = False

        num_updated = update_row(CustomerID, customername, address, phonenumber, email, sqft, roofage, conroof, roofgrade, mats)
        print(f'{num_updated} row(s) updated.')



def update_row(CustomerID, customername, address, phonenumber, email, sqft, roofage, conroof, roofgrade, mats):
    conn = None
    try:
        conn = sqlite3.connect('viperquotes.db')
        cur = conn.cursor()
        cur.execute('''UPDATE quotes SET customername = ?, address = ?, phonenumber = ?, email = ?, sqft = ?, roofage = ?, conroof = ?, roofgrade = ?, mats = ? WHERE (CustomerID) == ?''', (customername, address, phonenumber,email, sqft, roofage, conroof,roofgrade, mats, CustomerID))
        conn.commit()
        num_updated = cur.rowcount
        print('Update complete')
    except sqlite3.Error as err:
        print('Database Error', err)
    finally:
        if conn != None:
            conn.close()
    
    return num_updated

if __name__ == '__main__':
    update()