import sqlite3

def read(search):
    try:
        conn = sqlite3.connect('viperquotes.db')
        cur = conn.cursor()
        cur.execute(search)
        results = cur.fetchall()
        for row in results:
            CustomerID = row [0]
            customername = row [1]
            address = row [2]
            phonenumber = row [3]
            email = row [4]
            sqft = row [5]
            roofage = row [6]
            conroof = row [7]
            roofgrade = row[8]
            mats = row[9]
    except sqlite3.Error as err:
        print('Database Error', err)
    finally:
        if conn != None:
            conn.close()
    return results

if __name__ == '__main__':
    read()
