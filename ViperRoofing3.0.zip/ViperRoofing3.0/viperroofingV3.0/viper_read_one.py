import sqlite3, viper_create

def searchCustomerName():
    viper_create.housekeeping('Viper Search results')
    name = input('Enter Customers name: ')
    CustomerID, customername, address, phonenumber,email, sqft, roofage, conroof,roofgrade, mats = read_item(name)
    if CustomerID == "":
        CustomerID = "-1"
    else:
        print(f'Customer ID: {CustomerID:<10} Customer Name: {customername:<10} Address: {address:<10}')

    return CustomerID, customername, address, phonenumber,email, sqft, roofage, conroof,roofgrade, mats


def read_item(name):
    CustomerID = 0
    customername = ""
    address = ""
    phonenumber = ""
    email = ""
    sqft = 0
    roofage = 0
    conroof = 0
    roofgrade = ""
    mats = ""
    conn = None
    results = []
    try:
        conn = sqlite3.connect('viperquotes.db')
        cur = conn.cursor()
        cur.execute('''SELECT * FROM quotes WHERE lower (customername) == ?''',
                    (name.lower(),))
        results = cur.fetchall()
        print(results)
        for row in results:
            CustomerID = row [0]
            customername = row [1]
            address = row [2]
            phonenumber = row [3]
            email = row [4]
            sqft = row [5]
            roofage = row [6]
            conroof = row [7]
            roofgrade = row[8]
            mats = row[9]
    except sqlite3.Error as err:
        print ('Database Error', err)
    finally:
        if conn != None:
            conn.close()

    return CustomerID, customername, address, phonenumber,email, sqft, roofage, conroof,roofgrade, mats


if __name__ == '__main__':
    searchCustomerName()
