from flask import Flask, render_template, request, redirect
import viper_read, viper_create, viper_correct,viper_delete,viper_update, viper_read_one, login
customerInfo = []
logInfo = []

app = Flask(__name__)

#front end
@app.route("/about")
def about():
    return render_template("aboutus.html")
@app.route("/contact",methods = ['POST', 'GET'])
def contact():
    if request.method == 'POST':
        #stores the values of the html form item word to a python word in uppercase
        name = request.form['name'].upper()
        name = name.rstrip()
        if not name:
            #if name is blank, enter a name
            errormsg = "Enter a name"
        else:
            errormsg = ""
            address = request.form['address'].upper()
            pnumber = request.form['pnumber']
            email = request.form['email']
            sqft = -1
            success_code = viper_create.insert_contact_row(name,address,pnumber,email,sqft)
            if success_code == 0:
            #if the databse was updated and the value of success code was set to 0
                errormsg = "data added successfully"
                customerInfo.append(f"{name} | {address} | {pnumber} |{email}|")
            else:
                errormsg = "database error -- word already exist"
        return render_template("contact.html", customerInfo = customerInfo, errormsg = errormsg)
    else:
        return render_template("contact.html")

    #return render_template("contact.html")
@app.route("/services")
def services():
    return render_template("services.html")
@app.route("/")
def home():
    return render_template("roofindex.html")




# admin pages
@app.route("/admin",methods = ['POST', 'GET'])
def homePage():
    if request.method == "POST":
        if request.form['log'] == 'login':
            username = request.form['username']
            password = request.form['password']
            logCheck = login.login(username,password)
            if logCheck == True:
                return render_template("index.html")
            else:
                errormsg = "Wrong Password/ Username. CASE SENSITIVE"
                return render_template('login.html', errormsg = errormsg)
        elif request.form['log'] == 'home':
            return render_template("index.html")
        else:
            return render_template('login.html')
    else:
        return render_template('login.html')


@app.route("/update", methods = ['POST', 'GET'])
def update():
    if request.method == "POST":
        if request.form['btn_id'] == 'List':
            search = "SELECT * FROM quotes WHERE sqft == -1 ORDER BY CustomerID"
            #customerInfo = ""
            customerInfo = viper_read.read(search)

            return render_template("update.html", customerInfo = customerInfo)

        elif request.form['btn_id'] == 'Search':
                    #declares string values to fill later
            CustomerID = 0
            customername = ""
            name = ""
            address = ""
            phonenumber = ""
            email = ""
            sqft = 0
            roofage = 0
            conroof = 0
            roofgrade = ""
            mats = ""
            search = ""
            #search button will find any word matching uppercase and strip spaces from the end
            name = request.form['name'].upper()
            name = name.rstrip()
            if not name:
                #returns true if word is not there
                errormsg = "you must enter a name"
            else:
                errormsg = ""
                #empty the error msg, then get the values from read_one.read_item
                CustomerID, customername, address, phonenumber,email, sqft, roofage, conroof,roofgrade, mats = viper_read_one.read_item(name)
                if CustomerID == 0:
                    errormsg = "Database error, name not found"
                    return render_template("update.html", errormsg =errormsg)
                else:
                    errormsg = ""
            return render_template("update.html", CustomerID = CustomerID, customername = customername, address =address, phonenumber = phonenumber,email = email, sqft = sqft, roofage = roofage, conroof = conroof ,roofgrade = roofgrade, mats = mats, errormsg = errormsg)
        elif request.form['btn_id'] == 'Update':
            CustomerID = 0
            customername = ""
            name = ""
            address = ""
            phonenumber = ""
            email = ""
            sqft = 0
            roofage = 0
            conroof = 0
            roofgrade = ""
            mats = ""
            search = ""
            # the pythons cript canbe veiwed in terminal during runtime 
            print("processing update")
            CustomerID = request.form['CustomerID']
            customername = request.form['customername'].upper()
            address = request.form['address'].upper()
            phonenumber = request.form['phonenumber']
            email = request.form['email']
            sqft = request.form['sqft']
            roofage = request.form['roofage']
            conroof = request.form['conroof']
            roofgrade = request.form['roofgrade'].upper()
            mats = request.form['mats'].upper()
            if roofgrade != "3-TAB" and roofgrade != "LUXURY" and roofgrade != "ARCHITECTURAL":
                errormsg = "MUST BE 3-TAB, LUXURY OR ARCHITECTURAL"
                return render_template("update.html", errormsg = errormsg)
            else:
                num_updated = viper_update.update_row(CustomerID, customername, address, phonenumber,email, sqft, roofage, conroof,roofgrade, mats)
                if num_updated == 0:
                    errormsg = "no rows updated"
                else:
                    errormsg = num_updated,"ROW UPDATED"
                return render_template("update.html",CustomerID = CustomerID, customername = customername, address =address, phonenumber = phonenumber,email = email, sqft = sqft, roofage = roofage, conroof = conroof ,roofgrade = roofgrade, mats = mats,  errormsg = errormsg)
                #send to web page, else page keeps it running
    else:
        return render_template("update.html")
    return render_template("update.html")

@app.route('/read_delete')
def read_delete():
        search = "SELECT * FROM quotes ORDER BY CustomerID"
        customerInfo = ""
        customerInfo = viper_read.read(search)
        return render_template("delete.html", customerInfo = customerInfo)

@app.route("/delete/<string:row>", methods = ['POST', 'GET'])
def delete(row):
    viper_delete.delete_row(row)
    return redirect('/read_delete')


@app.route("/update/<string:row>", methods = ['POST', 'GET'])
def updatelist(row):
    CustomerID = 0
    customername = ""
    address = ""
    phonenumber = ""
    email = ""
    sqft = 0
    roofage = 0
    conroof = 0
    roofgrade = ""
    mats = ""
    #search = ""
    errormsg = ""
    CustomerID, customername, address, phonenumber,email, sqft, roofage, conroof,roofgrade, mats = viper_read_one.read_item(row)
    row = ""
    return render_template("update.html",CustomerID = CustomerID, customername = customername, address =address, phonenumber = phonenumber,email = email, sqft = sqft, roofage = roofage, conroof = conroof ,roofgrade = roofgrade, mats = mats,  errormsg = errormsg)


@app.route("/read/<string:flag>")
def read(flag):
    if flag == "all":
        search = "SELECT * FROM quotes ORDER BY CustomerID"
    elif flag == "architectural":
        search = "SELECT * FROM quotes WHERE roofgrade = 'ARCHITECTURAL' ORDER BY CustomerID"
    elif flag == "luxury":
        search = "SELECT * FROM quotes WHERE roofgrade = 'LUXURY' ORDER BY CustomerID"
    elif flag == "3-tab":
        search = "SELECT * FROM quotes WHERE roofgrade = '3-TAB' ORDER BY CustomerID"
    customerInfo = ""
    customerInfo = viper_read.read(search)
    return render_template("read.html", customerInfo = customerInfo)


@app.route("/readone", methods = ['POST', 'GET'])
def readone():
    if request.method == "POST":
        #declares string values to fill later
        CustomerID = 0
        customername = ""
        name = ""
        address = ""
        phonenumber = ""
        email = ""
        sqft = 0
        roofage = 0
        conroof = 0
        roofgrade = ""
        mats = ""
        if request.form['btn_id'] == 'Search':
            #search button will find any word matching uppercase and strip spaces from the end
            name = request.form['name'].upper()
            name = name.rstrip()
            if not name:
                #returns true if word is not there
                errormsg = "you must enter a name"
            else:
                errormsg = ""
                #empty the error msg, then get the values from read_one.read_item
                CustomerID, customername, address, phonenumber,email, sqft, roofage, conroof,roofgrade, mats = viper_read_one.read_item(name)
                if CustomerID == 0:
                    errormsg = "Database error, name not found"
                    return render_template("readone.html", errormsg = errormsg)
                else:
                    errormsg = ""
            return render_template("readone.html", CustomerID = CustomerID, customername = customername, address =address, phonenumber = phonenumber,email = email, sqft = sqft, roofage = roofage, conroof = conroof ,roofgrade = roofgrade, mats = mats, errormsg = errormsg)
    else:
        return render_template("readone.html")
    return render_template("readone.html")


    
@app.route("/create", methods = ['POST', 'GET'])#added by will
def create():
    if request.method == 'POST':
        #stores the values of the html form item word to a python word in uppercase
        name = request.form['name'].upper()
        name = name.rstrip()
        if not name:
            #if name is blank, enter a name
            errormsg = "Enter a name"
        else:
            errormsg = ""
            address = request.form['address'].upper()
            pnumber = request.form['pnumber']
            email = request.form['email']
            sqft = request.form['sqft']
            roofage = request.form['roofage']
            conroof = request.form['conroof']
            roofgrade = request.form['roofgrade']
            mats = request.form['mats']
            success_code = viper_create.insert_row(name,address,pnumber,email,sqft,roofage,conroof,roofgrade,mats)
            if success_code == 0:
            #if the databse was updated and the value of success code was set to 0
                errormsg = "data added successfully"
                customerInfo.append(f"{name} | {address} | {pnumber} |{email}|{sqft}|{roofage}|{conroof}|{roofgrade}|{mats}")
            else:
                errormsg = "database error -- word already exist"
        return render_template("create.html", customerInfo = customerInfo, errormsg = errormsg)
    else:
        return render_template("create.html")

#this route includes the flag from the html address bar to determine how to handle the if statments
    #return render_template("create.html")


############################################################
#login pages
@app.route("/logincreate", methods = ['POST', 'GET'])
def logincreate():
    if request.method == 'POST':
        #stores the values of the html form item word to a python word in uppercase
        username = request.form['username']
        username = username.rstrip()
        if not username:
            #if name is blank, enter a name
            errormsg = "Enter a name"
        else:
            errormsg = ""
            password = request.form['password']
            success_code = login.insert_row(username,password)
            if success_code == 0:
            #if the databse was updated and the value of success code was set to 0
                errormsg = "data added successfully"
                logInfo.append(f"{username} | {password} ")
            else:
                errormsg = "database error -- user exist"
        return render_template("logincreate.html", logInfo = logInfo, errormsg = errormsg)
    else:
        return render_template("logincreate.html")
@app.route("/loginupdate", methods = ['POST', 'GET'])
def loginupdate():
    if request.method == 'POST':
        username = ""
        password = ""
        if request.form['btn_id'] == 'Search':
            username = request.form['username']
            username = username.rstrip()
            if not username:
            #if name is blank, enter a name
                errormsg = "Enter a username"
            else:
                errormsg = ""
                username, password = login.read_one(username)
                #username , password = login.read(username,password)
                if username < "":
                    errormsg = "Database error, name not found"
                    return render_template('loginupdate.html', errormsg = errormsg, username = username, password = password)
                else:
                    errormsg = ''
                    return render_template('loginupdate.html', errormsg = errormsg, username = username, password = password)
            return render_template('loginupdate.html', errormsg = errormsg, username = username, password = password)
        elif request.form['btn_id'] == 'Update':
            username = request.form['username']
            username = username.rstrip()
            password = request.form['password']
            if not password:
            #if name is blank, enter a name
                errormsg = "Enter a password"
                return render_template("loginupdate.html", errormsg = errormsg)
            else:
                num_updated = login.update_row(username,password)
                if num_updated == 0:
                    errormsg = "no rows updated"
                else:
                    errormsg = num_updated,"ROW UPDATED"
            return render_template("loginupdate.html", errormsg = errormsg, username = username, password = password)
    else:
        return render_template("loginupdate.html")
@app.route("/login_read_delete", methods = ['POST', 'GET'])
def login_read_delete():
    search = "SELECT * FROM login "
    logInfo = []
    logInfo = login.read(search)
    return render_template("logindelete.html", logInfo = logInfo)
@app.route("/logindelete/<string:row>", methods = ['POST', 'GET'])
def login_delete(row):
    login.delete_row(row)
    return redirect('/login_read_delete')
            


