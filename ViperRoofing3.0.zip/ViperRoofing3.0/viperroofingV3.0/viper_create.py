import sqlite3

def create():
    #only customer given info goes on this function. this is not an admin page


    #updates the header
    housekeeping('Customer Contact page')
    i = False
    #ensures input is correct
    while i != True:
        print('Enter your details so we can reach out to you')
        name = input(f'{"Name:":{x}}')
        #name isnt primary key but need it anyway
        while name == "":
            name = input(f'{"You should enter a name:":{x}}')
        address = input(f'{"Address:":{x}}')
        pnumber = input(f'{"Phone #:":{x}}')
        email = input(f'{"Email:":{x}}')
        print(f'{"Name:":5}{name:5}\n{"Address:":5}{address:5}\n{"Phone Number:":5}{pnumber:5}\n{"Email:":5}{email:5}')
        checkInfo = input(f'{"Is this information correct? type y/n or  q to quit:":{x}} ')
        if checkInfo.lower() == 'y':
            i = True
            insert_row(name,address,pnumber,email)
        elif checkInfo.lower() == 'q':
            print('Goodbye!')
            i = True


    

def insert_row(name,address,pnumber,email,sqft,roofage,conroof,roofgrade,mats):
    #database kept seperate from main code
    conn = None
    try:
        conn = sqlite3.connect('viperquotes.db')
        cur = conn.cursor()
        cur.execute('''INSERT INTO quotes(customername,address,phonenumber,email,sqft,roofage,conroof,roofgrade,mats)
                    VALUES(?,?,?,?,?,?,?,?,?)''',
                    (name,address,pnumber,email,sqft,roofage,conroof,roofgrade,mats))
        conn.commit()
        print('row created!')
        success_code = 0
    except sqlite3.Error as err:
        success_code = -1
        print('Database Error' , err)
    finally:
        if conn != None:
            conn.close()
    return success_code
# for contact page
def insert_contact_row(name,address,pnumber,email,sqft):
    #database kept seperate from main code
    conn = None
    try:
        conn = sqlite3.connect('viperquotes.db')
        cur = conn.cursor()
        cur.execute('''INSERT INTO quotes(customername,address,phonenumber,email,sqft)
                    VALUES(?,?,?,?,?)''',
                    (name,address,pnumber,email,sqft))
        conn.commit()
        print('row created!')
        success_code = 0
    except sqlite3.Error as err:
        success_code = -1
        print('Database Error' , err)
    finally:
        if conn != None:
            conn.close()
    return success_code

def housekeeping(header):
    #I placed it here because i didnt want another start page. just something extra to try and make everything look nice
    i = 0
    global x 
    x = 100
    #formats the header and header line so that I can change what it says
    # and it will stay the correct length
    
    print(f'{"Viper roofing":{x}}{header}')
    while i < (x + len(header)):
        print('_', end="")
        i = i + 1
    print("")

if __name__ == '__main__':
    create()

